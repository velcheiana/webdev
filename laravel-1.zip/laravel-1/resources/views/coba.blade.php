Hello World as Controller

<div>
<h1>Title</h1>
</div>

@for ($i = 0; $i < 10; $i++)
Number - {{ $i }} <br>
@endfor

<h3>{{ $name }}</h3>

Page - {{ $p }}
